import { requireAuth, withAuth, ok, err, isValidPrefixedId } from '../../utils/guard.js';
import { computeItemProration, computePricingFloors, validateNonNegativeMoney } from '../../utils/auction.js';
import { CHUNK_SIZE } from '../../utils/constants.js';

// ============================================================
// GET    /api/invoices/:id  - get single invoice with items
// PUT    /api/invoices/:id  - update invoice + re-prorate all items
// DELETE /api/invoices/:id  - delete invoice (cascades to items)
// ============================================================

function getInvoiceId(url) {
  // pathname: /api/invoices/<id>
  const parts = url.pathname.split('/').filter(Boolean);
  const candidate = parts[parts.length - 1] || null;
  return isValidPrefixedId(candidate, ['inv', 'AMAZON']) ? candidate : null;
}

export async function onRequestGet(context) {
  const { request, env } = context;
  return withAuth(async () => {
    const payload = await requireAuth(request, env);
    if (!env.DB) return err('Database not available', 500);

    const id = getInvoiceId(new URL(request.url));
    if (!id) return err('Invoice ID required', 400);

    const invoice = await env.DB.prepare(
      'SELECT * FROM auction_invoices WHERE (id = ? OR invoice_ref = ?) AND user_id = ?'
    ).bind(id, id, payload.userId).first();

    if (!invoice) return err('Invoice not found', 404);

    const items = await env.DB.prepare(
      'SELECT * FROM auction_items WHERE invoice_id = ? AND user_id = ? ORDER BY created_at ASC'
    ).bind(invoice.id, payload.userId).all();

    return ok({ invoice, items: items.results || [] });
  });
}

export async function onRequestPut(context) {
  const { request, env } = context;
  return withAuth(async () => {
    const payload = await requireAuth(request, env);
    if (!env.DB) return err('Database not available', 500);

    const url = new URL(request.url);
    const id = getInvoiceId(url);
    if (!id) return err('Invoice ID required', 400);

    const invoice = await env.DB.prepare(
      'SELECT * FROM auction_invoices WHERE id = ? AND user_id = ?'
    ).bind(id, payload.userId).first();
    if (!invoice) return err('Invoice not found', 404);

    const body = await request.json();
    const { invoice_ref, description, discount, shipping, tax, date_acquired } = body;

    let newDiscount = invoice.discount;
    let newShipping = invoice.shipping;
    let newTax      = invoice.tax;

    try {
      if (discount !== undefined) {
        newDiscount = validateNonNegativeMoney(discount, 'discount') ?? invoice.discount;
      }
      if (shipping !== undefined) {
        newShipping = validateNonNegativeMoney(shipping, 'shipping') ?? invoice.shipping;
      }
      if (tax !== undefined) {
        newTax = validateNonNegativeMoney(tax, 'tax') ?? invoice.tax;
      }
    } catch (e) {
      return err(e.message, 400);
    }
    const newRef       = invoice_ref ?? invoice.invoice_ref;
    const newDesc      = description ?? invoice.description;
    const newDateAcq   = date_acquired ?? invoice.date_acquired;

    await env.DB.prepare(`
      UPDATE auction_invoices
      SET invoice_ref = ?, description = ?, discount = ?, shipping = ?, tax = ?, date_acquired = ?
      WHERE id = ? AND user_id = ?
    `).bind(newRef, newDesc, newDiscount, newShipping, newTax, newDateAcq, id, payload.userId).run();

    // Re-prorate all items under this invoice
    const existing = await env.DB.prepare(
      'SELECT * FROM auction_items WHERE invoice_id = ? AND user_id = ?'
    ).bind(id, payload.userId).all();

    const updatedInvoice = { ...invoice, discount: newDiscount, shipping: newShipping, tax: newTax };
    const updateStatements = [];

    for (const item of (existing.results || [])) {
      const proration = computeItemProration({ unit_price: item.unit_price }, updatedInvoice);
      const pricing   = computePricingFloors({
        true_total_cost:  proration.true_total_cost,
        est_shipping_cost: item.est_shipping_cost || 0,
        platform_flat_fee: item.platform_flat_fee || 0,
        platform_fee_pct:  item.platform_fee_pct  || 0,
        boost_pct:         item.boost_pct         || 0,
        target_margin_pct: item.target_margin_pct || 0
      });

      updateStatements.push(
        env.DB.prepare(`
          UPDATE auction_items
          SET proration_weight = ?, prorated_discount = ?, prorated_shipping = ?,
              prorated_tax = ?, true_total_cost = ?,
              min_sell_price = ?, suggested_list_price = ?, updated_at = datetime('now')
          WHERE id = ? AND user_id = ?
        `).bind(
          proration.proration_weight, proration.prorated_discount,
          proration.prorated_shipping, proration.prorated_tax, proration.true_total_cost,
          pricing.min_sell_price, pricing.suggested_list_price,
          item.id, payload.userId
        )
      );
    }

    try {
      if (updateStatements.length > 0) {
        const CHUNK_SIZE = 50;
        for (let i = 0; i < updateStatements.length; i += CHUNK_SIZE) {
          await env.DB.batch(updateStatements.slice(i, i + CHUNK_SIZE));
        }
      }
    } catch (reprorateErr) {
      console.error('[invoices] Failed to re-prorate items, reverting invoice:', reprorateErr);
      await env.DB.prepare(`
        UPDATE auction_invoices
        SET invoice_ref = ?, description = ?, discount = ?, shipping = ?, tax = ?, date_acquired = ?
        WHERE id = ? AND user_id = ?
      `).bind(invoice.invoice_ref, invoice.description, invoice.discount, invoice.shipping, invoice.tax, invoice.date_acquired, id, payload.userId).run().catch(() => {});
      return err('Failed to re-prorate invoice items. Invoice state restored.', 500);
    }

    return ok({ success: true, message: `Invoice updated and ${existing.results?.length || 0} items re-prorated.` });
  });
}

export async function onRequestDelete(context) {
  const { request, env } = context;
  return withAuth(async () => {
    const payload = await requireAuth(request, env);
    if (!env.DB) return err('Database not available', 500);

    const id = getInvoiceId(new URL(request.url));
    if (!id) return err('Invoice ID required', 400);

    const invoice = await env.DB.prepare(
      'SELECT id FROM auction_invoices WHERE id = ? AND user_id = ?'
    ).bind(id, payload.userId).first();
    if (!invoice) return err('Invoice not found', 404);

    // Check if any items in this invoice have sales
    const soldCheck = await env.DB.prepare(`
      SELECT COUNT(*) AS cnt FROM auction_sales s
      JOIN auction_items i ON i.id = s.item_id
      WHERE i.invoice_id = ? AND s.user_id = ?
    `).bind(id, payload.userId).first();

    if (soldCheck && soldCheck.cnt > 0) {
      return err('Cannot delete an invoice that has recorded sales. Archive items instead.', 409);
    }

    // Delete comps, items, and invoice atomically in a single batch
    const deleteCompsStmt = env.DB.prepare(
      'DELETE FROM auction_comps WHERE user_id = ? AND item_id IN (SELECT id FROM auction_items WHERE invoice_id = ? AND user_id = ?)'
    ).bind(payload.userId, id, payload.userId);

    const deleteItemsStmt = env.DB.prepare(
      'DELETE FROM auction_items WHERE invoice_id = ? AND user_id = ?'
    ).bind(id, payload.userId);

    const deleteInvStmt = env.DB.prepare(
      'DELETE FROM auction_invoices WHERE id = ? AND user_id = ?'
    ).bind(id, payload.userId);

    try {
      if (typeof env.DB.batch === 'function') {
        await env.DB.batch([deleteCompsStmt, deleteItemsStmt, deleteInvStmt]);
      } else {
        await deleteCompsStmt.run();
        await deleteItemsStmt.run();
        await deleteInvStmt.run();
      }
    } catch (delErr) {
      console.error('[invoices] Failed to delete invoice and associated items:', delErr);
      return err('Failed to delete invoice. Database state preserved.', 500);
    }

    return ok({ success: true });
  });
}
