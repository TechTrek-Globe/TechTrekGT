import { getApiUrl } from './api.js';
export { getApiUrl };
import { FALLBACK_GATEWAY_ORIGIN, LOCAL_DEV_ORIGIN } from '../../functions/utils/constants.js';

const JSON_HEADERS = { 'Content-Type': 'application/json' };
const OPTS = { credentials: 'include' };

/**
 * Resolves the landing API gateway base URL.
 *
 * T-10 item 9: no hardcoded production hostname. VITE_GATEWAY_BASE_URL (set per
 * environment) wins, so a staging build no longer calls production. Local dev
 * falls back to the wrangler dev port; otherwise the current origin is used.
 */
function getGatewayBase() {
  const configured = import.meta.env?.VITE_GATEWAY_BASE_URL;
  if (configured) return configured.replace(/\/$/, '');
  if (typeof window !== 'undefined' && window.location.hostname === 'localhost') {
    return LOCAL_DEV_ORIGIN;
  }
  if (typeof window !== 'undefined' && window.location.origin) {
    return window.location.origin;
  }
  return FALLBACK_GATEWAY_ORIGIN;
}
export { getGatewayBase };

function getAuthErrorMessage(status, dataError, path = '') {
  if (status === 401) {
    const isEbay = (typeof path === 'string' && path.includes('/ebay/')) || (typeof dataError === 'string' && /ebay/i.test(dataError));
    if (isEbay) {
      return dataError || 'eBay authentication required. Please connect your eBay account.';
    }
    if (!dataError || /unauthorized|expired|invalid token|missing token/i.test(dataError)) {
      return 'Your session has expired or authentication is required. Please refresh the page or sign in again.';
    }
  }
  return dataError || `HTTP ${status}`;
}

async function apiFetch(path, options = {}) {
  const res = await fetch(getApiUrl(path), { ...OPTS, ...options });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const isEbay = (typeof path === 'string' && path.includes('/ebay/')) || (typeof data.error === 'string' && /ebay/i.test(data.error));
    if (res.status === 401 && !isEbay && typeof window !== 'undefined' && typeof window.dispatchEvent === 'function') {
      const evt = typeof CustomEvent !== 'undefined'
        ? new CustomEvent('outpost:unauthorized', { detail: { path, error: data.error } })
        : { type: 'outpost:unauthorized', detail: { path, error: data.error } };
      window.dispatchEvent(evt);
    }
    throw new Error(getAuthErrorMessage(res.status, data.error, path));
  }
  if (data && data.success === false) {
    throw new Error(data.error || 'Request failed');
  }
  return data;
}

// --- Invoices ---
export const getInvoices = () =>
  apiFetch('/api/invoices');

export const getInvoice = (idOrRef) =>
  apiFetch(`/api/invoices/${encodeURIComponent(idOrRef)}`);

export const createInvoice = (body) =>
  apiFetch('/api/invoices', {
    method: 'POST',
    headers: JSON_HEADERS,
    body: JSON.stringify(body)
  });

export const updateInvoice = (id, body) =>
  apiFetch(`/api/invoices/${id}`, {
    method: 'PUT',
    headers: JSON_HEADERS,
    body: JSON.stringify(body)
  });

export const deleteInvoice = (id) =>
  apiFetch(`/api/invoices/${id}`, { method: 'DELETE' });

// --- Items ---
export const getItem = (id) =>
  apiFetch(`/api/items/${encodeURIComponent(id)}`);

export const getItems = (params = {}) => {
  const qs = new URLSearchParams(
    Object.fromEntries(Object.entries(params).filter(([, v]) => v != null && v !== ''))
  ).toString();
  return apiFetch(`/api/items${qs ? `?${qs}` : ''}`);
};

export const getEnrichedItems = (params = {}, options = {}) => {
  const qs = new URLSearchParams(
    Object.fromEntries(Object.entries(params).filter(([, v]) => v != null && v !== ''))
  ).toString();
  return apiFetch(`/api/items/enriched${qs ? `?${qs}` : ''}`, options);
};

export const updateItem = (id, body) =>
  apiFetch(`/api/items/${id}`, {
    method: 'PUT',
    headers: JSON_HEADERS,
    body: JSON.stringify(body)
  });

export const deleteItem = (id) =>
  apiFetch(`/api/items/${id}`, { method: 'DELETE' });


// --- Sales ---
export const getSales = (params = {}) => {
  const qs = new URLSearchParams(
    Object.fromEntries(Object.entries(params).filter(([, v]) => v != null && v !== ''))
  ).toString();
  return apiFetch(`/api/sales${qs ? `?${qs}` : ''}`);
};

export const getSale = (id) =>
  apiFetch(`/api/sales/${id}`);

export const createSale = (body) =>
  apiFetch('/api/sales', {
    method: 'POST',
    headers: JSON_HEADERS,
    body: JSON.stringify(body)
  });

export const updateSale = (id, body) =>
  apiFetch(`/api/sales/${id}`, {
    method: 'PUT',
    headers: JSON_HEADERS,
    body: JSON.stringify(body)
  });

export const deleteSale = (id) =>
  apiFetch(`/api/sales/${id}`, { method: 'DELETE' });

// --- Platforms ---
export const getPlatforms = () =>
  apiFetch('/api/platforms');

export const createPlatform = (body) =>
  apiFetch('/api/platforms', {
    method: 'POST',
    headers: JSON_HEADERS,
    body: JSON.stringify(body)
  });

export const updatePlatform = (id, body) =>
  apiFetch(`/api/platforms/${id}`, {
    method: 'PUT',
    headers: JSON_HEADERS,
    body: JSON.stringify(body)
  });

export const deletePlatform = (id) =>
  apiFetch(`/api/platforms/${id}`, { method: 'DELETE' });

export const resetPlatforms = () =>
  apiFetch('/api/platforms', {
    method: 'POST',
    headers: JSON_HEADERS,
    body: JSON.stringify({ action: 'reset_defaults' })
  });

// --- Comps / Pricing Intelligence ---
export const getComps = (params = {}) => {
  if (typeof params === 'string') {
    const qs = params.startsWith('?') ? params.slice(1) : params;
    return apiFetch(`/api/comps?${qs}`);
  }
  const q = new URLSearchParams();
  if (params.item_id) q.set('item_id', params.item_id);
  if (params.status) q.set('status', params.status);
  const qs = q.toString();
  return apiFetch(`/api/comps${qs ? `?${qs}` : ''}`);
};

export const saveComp = (body) =>
  apiFetch('/api/comps', {
    method: 'POST',
    headers: JSON_HEADERS,
    body: JSON.stringify(body)
  });

export const updateComp = (id, body) =>
  apiFetch(`/api/comps/${id}`, {
    method: 'PUT',
    headers: JSON_HEADERS,
    body: JSON.stringify(body)
  });

export const deleteComp = (id) =>
  apiFetch(`/api/comps/${id}`, { method: 'DELETE' });

// --- Dashboard ---
export const getDashboard = () =>
  apiFetch('/api/dashboard');

// --- Live eBay Comps (via Central API Gateway) ---
// Gateway endpoint: POST https://techtrekgt.com/api/ebay/comps
// Uses official eBay REST API (Marketplace Insights + Browse fallback).
// Option A: gateway returns raw data; caller uses saveComp() to persist to D1 if itemId is set.
export const fetchLiveComps = (query, itemId = null) =>
  fetch(`${getGatewayBase()}/api/ebay/comps`, {
    method: 'POST',
    credentials: 'include',
    headers: JSON_HEADERS,
    body: JSON.stringify({ query, itemId })
  }).then(async r => {
    const data = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(getAuthErrorMessage(r.status, data.error, '/api/ebay/comps'));
    return data;
  });

// --- eBay Catalog Search (via Central API Gateway) ---
export const fetchEbayCatalog = (query) =>
  fetch(`${getGatewayBase()}/api/ebay/catalog?q=${encodeURIComponent(query)}`, {
    credentials: 'include',
    headers: JSON_HEADERS
  }).then(async r => {
    const data = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(getAuthErrorMessage(r.status, data.error, '/api/ebay/catalog'));
    return data;
  });

// --- eBay Item Details (via Central API Gateway) ---
export const fetchEbayItemDetail = (idOrUrl) => {
  const clean = String(idOrUrl || '').trim();
  const m = clean.match(/(?:itm\/|item=|\b)(\d{12})\b/);
  const targetId = m ? m[1] : clean;
  return fetch(`${getGatewayBase()}/api/ebay/item/${encodeURIComponent(targetId)}`, {
    credentials: 'include',
    headers: JSON_HEADERS
  }).then(async r => {
    const data = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(getAuthErrorMessage(r.status, data.error, '/api/ebay/item'));
    return data;
  });
};

// --- Amazon Product Fetch (via Central API Gateway) ---
// Gateway endpoint: POST https://techtrekgt.com/api/amazon/fetch
// Scrapes/parses Amazon product metadata from a URL or ASIN.
export const fetchAmazonProduct = (input) =>
  fetch(`${getGatewayBase()}/api/amazon/fetch`, {
    method: 'POST',
    credentials: 'include',
    headers: JSON_HEADERS,
    body: JSON.stringify({ input })
  }).then(async r => {
    const data = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(data.error || `HTTP ${r.status}`);
    return data;
  });

// --- TechTrek Finance Cross-Portal Sync ---
export const getFinanceSyncMetrics = () =>
  apiFetch('/api/sync/finance');

export const syncToFinance = (options = {}) =>
  apiFetch('/api/sync/finance', {
    method: 'POST',
    headers: JSON_HEADERS,
    body: JSON.stringify(options)
  });

// --- Year-End Tax & Schedule C Reports ---
export const getTaxReport = (year = '') =>
  apiFetch(`/api/reports/tax${year ? `?year=${encodeURIComponent(year)}` : ''}`);

// ============================================================
// PHASE 3 - eBay Real-Time Sync Engine API Utilities
// ============================================================

// --- eBay OAuth Status ---
export const getEbayOAuthStatus = () =>
  apiFetch('/api/ebay/oauth-status');

// --- eBay Listing ID (PATCH item) ---
export const saveEbayListingId = (itemId, ebayListingId, certVerificationUrl = null, ebayPromotedRate = null) =>
  apiFetch(`/api/items/${itemId}`, {
    method: 'PUT',
    headers: JSON_HEADERS,
    body: JSON.stringify({
      ebay_listing_id: ebayListingId || null,
      cert_verification_url: certVerificationUrl || null,
      ebay_promoted_rate: ebayPromotedRate != null ? parseFloat(ebayPromotedRate) : null
    })
  });

// --- eBay Delist Pending: mark item Sold from the delist alert ---
export const resolveDelistPending = (itemId) =>
  apiFetch(`/api/items/${itemId}`, {
    method: 'PUT',
    headers: JSON_HEADERS,
    body: JSON.stringify({ status: 'Sold' })
  });

// --- eBay Active Listing Discovery ---
export const findEbayListings = () =>
  apiFetch('/api/ebay/find-listings');

// --- eBay Active Listings (On-Demand Picker) ---
export const getActiveEbayListings = (params = {}) => {
  const qs = new URLSearchParams(params).toString();
  return apiFetch(`/api/ebay/active-listings${qs ? `?${qs}` : ''}`);
};

// --- eBay Fee Reconciliation ---
export const reconcileSaleFees = (saleId, ebayOrderId) =>
  apiFetch('/api/ebay/reconcile', {
    method: 'POST',
    headers: JSON_HEADERS,
    body: JSON.stringify({ sale_id: saleId, ebay_order_id: ebayOrderId })
  });

// --- eBay Auto-Sync Single Item ---
export const syncEbayItem = (itemId, ebayListingId = null, ebayPromotedRate = null) =>
  apiFetch('/api/ebay/sync-item', {
    method: 'POST',
    headers: JSON_HEADERS,
    body: JSON.stringify({
      item_id: itemId,
      ebay_listing_id: ebayListingId,
      ebay_promoted_rate: ebayPromotedRate != null ? parseFloat(ebayPromotedRate) : null
    })
  });

// --- eBay Batch Sync All Linked Items ---
export const syncAllEbayItems = () =>
  apiFetch('/api/ebay/sync-all', {
    method: 'POST',
    headers: JSON_HEADERS
  });

// --- eBay Sell Analytics (Traffic & Performance Report) ---
export const fetchEbayItemAnalytics = (itemId, range = 30, force = false) =>
  apiFetch(`/api/ebay/analytics?item_id=${encodeURIComponent(itemId)}&range=${range}${force ? '&force=true' : ''}`);

// --- SKU Auto-Assignment & eBay Push Engine ---
export const autoAssignSkus = () =>
  apiFetch('/api/items/auto-sku', {
    method: 'POST',
    headers: JSON_HEADERS
  });

export const pushSkuToEbay = (itemId, sku = null) =>
  apiFetch('/api/ebay/push-sku', {
    method: 'POST',
    headers: JSON_HEADERS,
    body: JSON.stringify({ item_id: itemId, sku })
  });

export const pushAllSkusToEbay = () =>
  apiFetch('/api/ebay/push-sku', {
    method: 'POST',
    headers: JSON_HEADERS,
    body: JSON.stringify({ all: true })
  });

// --- VineScout Sync Catalog ---
export const getVineScoutCatalog = () =>
  apiFetch('/api/sync/vinescout-catalog');

// --- Sync Engine Settings ---
export const getSyncSettings = () =>
  apiFetch('/api/sync/settings');

export const updateSyncSettings = (body) =>
  apiFetch('/api/sync/settings', {
    method: 'PUT',
    headers: JSON_HEADERS,
    body: JSON.stringify(body)
  });

// --- VScout Sale Write-Back ---
export const writeBackVScoutSale = (itemId, saleData) =>
  apiFetch('/api/sync/vinescout-catalog', {
    method: 'POST',
    headers: JSON_HEADERS,
    body: JSON.stringify({ item_id: itemId, ...saleData })
  });

// --- Image Preview Resolver ---
export const getItemImagePreview = ({ id, ebay_listing_id, asin }) => {
  const params = new URLSearchParams();
  if (id) params.set('id', id);
  if (ebay_listing_id) params.set('ebay_listing_id', ebay_listing_id);
  if (asin) params.set('asin', asin);
  return apiFetch(`/api/items/image-preview?${params.toString()}`);
};

// --- Match Sold eBay to Vine Scout ---
export const getSoldEbayVineMatches = () =>
  apiFetch('/api/ebay/match-sold-vinescout');

export const confirmSoldEbayVineMatch = (payload) =>
  apiFetch('/api/ebay/match-sold-vinescout', {
    method: 'POST',
    headers: JSON_HEADERS,
    body: JSON.stringify({ confirm: true, ...payload })
  });

// --- API Integrations (HIGH-2) ---
export const getIntegrations = () =>
  apiFetch('/api/integrations');

export const createIntegration = (body) =>
  apiFetch('/api/integrations', {
    method: 'POST',
    headers: JSON_HEADERS,
    body: JSON.stringify(body)
  });

export const revokeIntegration = (id) =>
  apiFetch(`/api/integrations/${encodeURIComponent(id)}/revoke`, {
    method: 'POST',
    headers: JSON_HEADERS
  });

