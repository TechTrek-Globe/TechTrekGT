import React, { useState, useEffect, useCallback } from 'react';
import {
  ShoppingBag, CheckCircle2, XCircle, AlertTriangle, ExternalLink,
  RefreshCw, Search, Loader2, Unlink, Zap
} from 'lucide-react';
import { getEbayOAuthStatus, findEbayListings, syncAllEbayItems, getGatewayBase } from '../utils/auctionApi';

// T-10 item 9: resolved through the shared helper so there is no second
// hardcoded hostname to drift.
const GATEWAY_BASE = getGatewayBase();

/**
 * EbayConnectBanner
 *
 * Displays in Settings > eBay Integration section.
 * Shows OAuth connection status, connect/disconnect controls,
 * "Find Active Listings" discovery trigger, and "Sync All Linked Listings".
 *
 * Props:
 *   onFindListings(matches) - called with fuzzy match results for ListingMatchReviewModal
 */
export function EbayConnectBanner({ onFindListings }) {
  const [status, setStatus] = useState(null);
  const [loading, setLoading] = useState(true);
  const [finding, setFinding] = useState(false);
  const [syncingAll, setSyncingAll] = useState(false);
  const [syncMsg, setSyncMsg] = useState('');
  const [error, setError] = useState('');
  const [disconnecting, setDisconnecting] = useState(false);

  const fetchStatus = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const data = await getEbayOAuthStatus();
      setStatus(data);
    } catch (e) {
      const msg = e.message || '';
      if (!msg.toLowerCase().includes('not connected') && !msg.toLowerCase().includes('connect your ebay account')) {
        setError(msg);
      }
      setStatus({ connected: false });
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchStatus();
    // Auto-reload status if user just returned from OAuth redirect
    const params = new URLSearchParams(window.location.search);
    if (params.get('ebay') === 'connected') {
      fetchStatus();
      window.history.replaceState({}, '', window.location.pathname);
    } else if (params.get('ebay') === 'error') {
      const reason = params.get('reason') || '';
      const detail = params.get('detail') || '';
      const status = params.get('status') || '';
      const reasonMap = {
        token_exchange: `eBay token exchange failed${status ? ` (HTTP ${status})` : ''}. Please verify that your eBay developer credentials are active.`,
        invalid_state: 'The OAuth state parameter expired or was invalid. Please try connecting again.',
        access_denied: 'eBay authorization was cancelled or denied.',
        server_config: 'Server configuration error: missing required environment secrets or bindings.',
        missing_params: 'Missing required OAuth response parameters from eBay.',
        invalid_scope: 'One or more requested permissions are not approved on your eBay developer account.'
      };
      const baseMsg = reasonMap[reason] || `eBay connection failed (${reason}). Please try again.`;
      setError(detail ? `${baseMsg} (${detail})` : baseMsg);
      window.history.replaceState({}, '', window.location.pathname);
    }
  }, [fetchStatus]);

  const handleConnect = (e) => {
    if (e && typeof e.preventDefault === 'function') e.preventDefault();
    window.location.href = `${GATEWAY_BASE}/api/ebay/oauth/start`;
  };

  const handleDisconnect = async () => {
    if (!window.confirm('Disconnect your eBay account? Webhooks and fee reconciliation will stop working.')) return;
    setDisconnecting(true);
    setError('');
    setSyncMsg('');
    try {
      const res = await fetch(`${GATEWAY_BASE}/api/ebay/oauth/disconnect`, {
        method: 'DELETE',
        credentials: 'include'
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error || `HTTP ${res.status}`);
      await fetchStatus();
    } catch (e) {
      setError(`Disconnect failed: ${e.message}`);
      fetchStatus();
    } finally {
      setDisconnecting(false);
    }
  };

  const handleFindListings = async () => {
    setFinding(true);
    setError('');
    try {
      const data = await findEbayListings();
      if (data && data.success === false && data.error) {
        throw new Error(data.error);
      }
      if (onFindListings) onFindListings(data.matches || [], data);
      // Reflect the refreshed timestamp in local state without a full refetch
      setStatus(prev => prev ? { ...prev, last_refreshed_at: new Date().toISOString() } : prev);
    } catch (e) {
      const msg = e.message || '';
      if (msg.includes('sell.inventory') || msg.includes('scope approval')) {
        setError('eBay Sell Inventory scope not approved. Apply for sell.inventory.readonly at developer.ebay.com.');
      } else if (msg.includes('not connected') || msg.includes('expired') || msg.includes('reconnect')) {
        setError('eBay account not connected or token expired. Please connect your eBay account.');
        setStatus({ connected: false });
      } else if (msg.includes('Endpoint not found') || msg.includes('gateway')) {
        setError('Backend routing error. Please contact support.');
      } else {
        setError(`Listing discovery failed: ${msg}`);
      }
    } finally {
      setFinding(false);
    }
  };

  const handleSyncAll = async () => {
    setSyncingAll(true);
    setSyncMsg('');
    setError('');
    try {
      const res = await syncAllEbayItems();
      if (res && res.success === false && res.error) {
        throw new Error(res.error);
      }
      setSyncMsg(res.message || `Successfully synced ${res.updated_count || 0} linked listings!`);
      setStatus(prev => prev ? { ...prev, last_refreshed_at: new Date().toISOString() } : prev);
      setTimeout(() => setSyncMsg(''), 5000);
    } catch (e) {
      const msg = e.message || '';
      if (msg.includes('not connected') || msg.includes('expired') || msg.includes('reconnect')) {
        setError('eBay account not connected or token expired. Please connect your eBay account.');
        setStatus({ connected: false });
      } else {
        setError(msg || 'Batch sync failed');
      }
    } finally {
      setSyncingAll(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center gap-2 text-slate-500 text-xs py-2">
        <Loader2 className="w-3.5 h-3.5 animate-spin" />
        Checking eBay connection...
      </div>
    );
  }

  if (!status?.connected) {
    return (
      <div className="p-4 rounded-xl bg-slate-900 border border-slate-700 space-y-3">
        <div className="flex items-center gap-2">
          <ShoppingBag className="w-4 h-4 text-amber-400" />
          <span className="text-sm font-bold text-white">eBay Integration</span>
          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-800 text-slate-400 border border-slate-700">NOT CONNECTED</span>
        </div>
        <p className="text-xs text-slate-400">
          Connect your eBay seller account to enable real-time webhook notifications,
          automatic fee reconciliation via the Finances API, and active listing discovery.
        </p>
        {error && (
          <div className="flex items-center gap-1.5 text-xs text-red-400">
            <AlertTriangle className="w-3.5 h-3.5 flex-shrink-0" /> {error}
          </div>
        )}
        <button
          type="button"
          id="ebay-connect-btn"
          onClick={handleConnect}
          className="flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-bold bg-amber-500 hover:bg-amber-400 text-slate-950 transition-all shadow-sm"
        >
          <ShoppingBag className="w-3.5 h-3.5" />
          Connect eBay Account
        </button>
      </div>
    );
  }

  const daysLeft = status.days_until_expiry ?? 99;

  return (
    <div className="p-4 rounded-xl bg-slate-900 border border-slate-700 space-y-3">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center gap-2">
          <ShoppingBag className="w-4 h-4 text-green-400" />
          <span className="text-sm font-bold text-white">eBay Integration</span>
          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-green-500/10 text-green-400 border border-green-500/20">CONNECTED</span>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <button
            type="button"
            id="ebay-sync-all-btn"
            onClick={handleSyncAll}
            disabled={syncingAll}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-300 border border-emerald-500/20 transition-all disabled:opacity-50"
            title="Update prices, dates, and status for all linked inventory items"
          >
            {syncingAll ? <Loader2 className="w-3 h-3 animate-spin" /> : <Zap className="w-3 h-3" />}
            {syncingAll ? 'Syncing All...' : 'Sync All Linked Listings'}
          </button>
          <button
            type="button"
            id="ebay-find-listings-btn"
            onClick={handleFindListings}
            disabled={finding}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-blue-500/10 hover:bg-blue-500/20 text-blue-300 border border-blue-500/20 transition-all disabled:opacity-50"
          >
            {finding ? <Loader2 className="w-3 h-3 animate-spin" /> : <Search className="w-3 h-3" />}
            {finding ? 'Searching...' : 'Find Listings'}
          </button>
          <button
            type="button"
            id="ebay-refresh-status-btn"
            onClick={fetchStatus}
            className="p-1.5 rounded-lg text-slate-500 hover:text-slate-300 hover:bg-slate-800 transition-all"
            title="Refresh status"
          >
            <RefreshCw className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            id="ebay-disconnect-btn"
            onClick={handleDisconnect}
            disabled={disconnecting}
            className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-semibold text-red-400 bg-red-500/10 hover:bg-red-500/20 border border-red-500/20 transition-all disabled:opacity-50"
          >
            {disconnecting ? <Loader2 className="w-3 h-3 animate-spin" /> : <Unlink className="w-3 h-3" />}
            {disconnecting ? 'Disconnecting...' : 'Disconnect'}
          </button>
        </div>
      </div>

      {syncMsg && (
        <div className="flex items-center gap-2 p-2.5 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-xs text-emerald-300">
          <CheckCircle2 className="w-3.5 h-3.5 flex-shrink-0" />
          {syncMsg}
        </div>
      )}

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
        <InfoCell label="eBay Account" value={status.ebay_user_id || 'Connected'} icon={<CheckCircle2 className="w-3 h-3 text-green-400" />} />
        <InfoCell label="Token Expires" value={`${daysLeft}d`} icon={daysLeft < 30 ? <AlertTriangle className="w-3 h-3 text-amber-400" /> : <CheckCircle2 className="w-3 h-3 text-green-400" />} />
        <InfoCell label="Connected" value={status.connected_at ? new Date(status.connected_at).toLocaleDateString() : '-'} />
        <InfoCell label="Last Refresh" value={status.last_refreshed_at ? new Date(status.last_refreshed_at).toLocaleDateString() : 'Never'} />
      </div>

      {daysLeft < 30 && (
        <div className="flex items-center gap-2 p-2.5 rounded-lg bg-amber-500/10 border border-amber-500/20 text-xs text-amber-300">
          <AlertTriangle className="w-3.5 h-3.5 flex-shrink-0" />
          Refresh token expires in {daysLeft} days. Disconnect and reconnect before it expires to maintain webhook access.
        </div>
      )}

      <div className="text-[10px] text-slate-500">
        Scopes: {(status.scopes || '').split(' ').filter(Boolean).length} active
        {' '}
        {!(status.scopes || '').includes('sell.finances') && (
          <span className="text-amber-400 ml-1">
            (sell.finances pending approval - fee reconciliation unavailable until approved)
          </span>
        )}
      </div>

      {status.scope_flags && !status.scope_flags.has_sell_inventory && (
        <div className="flex items-center gap-2 p-2.5 rounded-lg bg-blue-500/10 border border-blue-500/20 text-xs text-blue-300">
          <AlertTriangle className="w-3.5 h-3.5 flex-shrink-0" />
          Listing discovery requires <strong>sell.inventory.readonly</strong> scope approval at
          {' '}<a href="https://developer.ebay.com" target="_blank" rel="noopener noreferrer" className="underline">developer.ebay.com</a>.
        </div>
      )}

      {status.scope_flags && !status.scope_flags.has_sell_analytics && (
        <div className="flex items-center justify-between gap-3 p-3 rounded-lg bg-purple-500/10 border border-purple-500/30 text-xs text-purple-300 flex-wrap">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-purple-400 flex-shrink-0" />
            <span>Listing traffic and conversion analytics requires the <strong>sell.analytics.readonly</strong> permission.</span>
          </div>
          <button
            type="button"
            onClick={handleConnect}
            className="px-2.5 py-1 rounded bg-purple-500 hover:bg-purple-400 text-slate-950 font-bold text-[11px] transition-all flex items-center gap-1 flex-shrink-0"
          >
            <span>Upgrade Permissions</span>
            <ExternalLink className="w-3 h-3" />
          </button>
        </div>
      )}

      {error && (
        <div className="flex items-center gap-1.5 text-xs text-red-400">
          <AlertTriangle className="w-3.5 h-3.5 flex-shrink-0" /> {error}
        </div>
      )}
    </div>
  );
}

function InfoCell({ label, value, icon }) {
  return (
    <div className="space-y-0.5">
      <div className="text-slate-500 text-[10px] uppercase tracking-wide">{label}</div>
      <div className="flex items-center gap-1 text-slate-200 font-semibold">
        {icon}{value}
      </div>
    </div>
  );
}
